#include "Type.h"
int equal(double, double, double);
#define INACCURACY pow(10, -10)
#define equali(a, b) equal(a, b, INACCURACY)