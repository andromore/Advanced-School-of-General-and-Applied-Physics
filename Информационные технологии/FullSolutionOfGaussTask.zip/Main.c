#include "MethodGauss.h"
#include <time.h>

// Режим сборки: INPUT = 0 (Ручной ввод - сначала запрашивается количество неизвестных, потом количество уравнений, потом коэффициенты системы поштучно) | RANDOM = 1 (Генерация коэффициентов - коэффициенты генерируются автоматически и система решается, как будто она была введена пользователем) | GENERATION 2 (Генерация неизвестных)
#define MODE 0

// Получение случайного значения
#define RANDOM (double) (rand() / RAND_MAX) + 1 // + 1 Чтобы точно не было 0

int main()
{
    int i, j, n, m;
    double tmp;
#if (MODE == 0) || (MODE == 1)
    printf("Enter number of variables (n): ");
    if (scanf("%d", &n) == 0)
    {
        printf("I'm sorry, but I don't understand you. (Your input is incorrect)\n");
        return 0;
    }
    printf("Enter number of equations (m): ");
    if (scanf("%d", &m) == 0)
    {
        printf("I'm sorry, but I don't understand you. (Your input is incorrect)\n");
        return 0;
    }
#elif MODE == 2 // В режиме 2 нет параметров
    printf("Enter rank of matrix: ");
    if (scanf("%d", &n) == 0)
    {
        printf("I'm sorry, but I don't understand you. (Your input is incorrect)\n");
        return 0;
    }
    m = n;
#else
#error
#endif
    if ((1 < n) && (n < 255) && (1 < m) && (m < 256))
    {
        Matrix a = New(m, n + 1);
        
        // Заполнение системы
#if MODE == 0 // INPUT
        printf("General view of the system of equations:\n1: a[1][1] * x[1] + a[1][2] * x[2] + ... + a[1][n] * x[n] + b[1] = 0\n2: a[2][1] * x[1] + a[2][2] * x[2] + ... + a[2][n] * x[n] + b[2] = 0\n   ...\nm: a[m][1] * x[1] + a[m][2] * x[2] + ... + a[m][n] * x[n] + b[m] = 0\nEnter the elements of augmented matrix:\n");
        for (i = 0; i < m; i++)
        {
            for (j = 0; j < n + 1; j++)
            {
                if (j != n)
                {
                    printf("a[%d][%d]: ", i + 1, j + 1);
                }
                else
                {
                    printf("b[%d]: ", i + 1);
                }
                if (scanf("%lf", &a.pointer[i * (n + 1) + j]) == 0)
                {
                    printf("I'm sorry, but I don't understand you. (Your input is incorrect)\n");
                    return 0;
                }
            }
        }
        printf("The entered system of equations:\n");
        Print(&a);
#elif MODE == 1 // RANDOM
        srand(time(NULL));
        for (i = 0; i < m; i++)
        {
            for (j = 0; j < n + 1; j++)
            {
                a.pointer[i * (n + 1) + j] = RANDOM;
            }
        }
        printf("Generated system of equations:\n");
        Print(&a);
#elif MODE == 2 // GENERATION
        srand(time(NULL));
        double z[n]; // Для сгенерированных значений неизвестных
        printf("Generated solution:\n");
        for (i = 0; i < n; i++) // Генерация значений неизвестных
        {
            tmp = RANDOM;
            z[i] = tmp;
            printf("x[%d] = %lf\n", i + 1, tmp);
        }
        for (i = 0; i < m; i++) // Генерация коэффициентов и свободных членов - в зависимости от сгенерированных коэффициентов и неизвестных вычисляются значения свободных членов
        {
            double b = 0;
            for (j = 0; j < n; j++)
            {
                a.pointer[i * (n + 1) + j] = RANDOM;
                b += a.pointer[i * (n + 1) + j] * z[j];
            }
            Set(&a, i, n, -b);
        }
        printf("Generated system of equations:\n");
        Print(&a);
        double q[n]; // Вычисленные значения неизвестных
#else
#error
#endif
        Matrix x = GaussMethod(&a); // Решение системы
        Free(&a); // Система больше не нужна

        // Вывод результата
        int y[x.columns - 1]; // Список распечатанных элементов: -1 - нет, 0 - главная, 1 - параметр.
        for (i = 0; i < x.columns; i++)
        {
            y[i] = -1;
        }
        
        // Приведение диагонали к единичному виду
        for (i = 0; i < x.rows; i++)
        {
            int a = -1;
            for (j = 0; j < x.columns; j++)
            {
                if (!equali(Get(&x, i, j), 0))
                {
                    a = j;
                    break;
                }
            }
            ComposeRowToNumber(&x, i, 1 / Get(&x, i, a));
        }
        
        // Проверка на наличие решений
        for (i = x.rows - 1; i >= 0; i--)
        {
            int a = -1;
            for (j = 0; j < x.columns - 1; j++)
            {
                if (!equali(Get(&x, i, j), 0))
                {
                    a = j;
                    break;
                }
            }
            if ((a == -1) && (!equali(Get(&x, i, x.columns - 1), 0))) // 0 * (x[1] + x[2] + ...) = b
            {
                printf("This system has no solution\n");
                return 0;
            }
        }
        
        // Главные переменные
        printf("Solution is:\n");
        for (i = 0; i < x.rows; i++)
        {
            int a = -1;
            for (j = 0; j < x.columns - 1; j++) // Поиск главной переменной в строке
            {
                if (!equali(Get(&x, i, j), 0)) // Главная переменная обнаружена
                {
                    a = j;
                    y[j] = 0;
                    break;
                }
            }
            if (a != -1) // Значения главных переменных
            {
                printf("x[%d] = ", a + 1);
                printf("(%lf)", - Get(&x, i, x.columns - 1));
#if (MODE == 0) || (MODE == 1) // В режиме 2 не может быть параметров
                for (j = a + 1; j < x.columns - 1; j++)
                {
                    if (!equali(Get(&x, i, j), 0)) // Параметр обнаружен
                    {
                        printf(" + (%lf) * x[%d]", - Get(&x, i, j), j + 1);
                        y[j] = 1;
                    }
                }
#elif MODE == 2
                q[i] = - Get(&x, i, x.columns - 1) - z[i];
#else
#error
#endif
                printf("\n");
            }
        }
        
        // Переменные, от значения которых ничего не зависит
        j = 0;
        printf("This variables can have any values: ");
        for (i = 0; i < x.columns - 1; i++)
        {
            if ((y[i] == -1) && (j == 0))
            {
                printf("x[%d]", i + 1);
                j++;
            }
            elif (y[i] == -1)
            {
                printf(", x[%d]", i + 1);
            }
        }
        if (j == 0)
        {
            printf("no variables");
        }
        
        // Параметры
        j = 0;
        printf("\nThis variables are parameters: ");
        for (i = 0; i < x.columns - 1; i++)
        {
            if ((y[i] == 1) && (j == 0))
            {
                printf("x[%d]", i + 1);
                j++;
            }
            elif (y[i] == 1)
            {
                printf(", x[%d]", i + 1);
            }
        }
        if (j == 0)
        {
            printf("no variables");
        }
        printf("\n");
#if MODE == 2 // Подсчёт среднего квадратичного отклонения
        double r = 0;
        for (i = 0; i < n; i++)
        {
            r += pow(q[i], 2);
        }
        printf("The average quadratic error of calculations: %le\n", pow(r, 0.5));
#endif
        Free(&x); // Матрица решений больше не нужна
    }
    elif ((n > 255) || (m > 255))
    {
        printf("O, I'm sorry, but it's too long for me...\n");
    }
    elif ((n == 1) || (m == 1))
    {
        printf("Do I really have to decide this?\n");
    }
    else
    {
        printf("It's a good joke, but no...\n");
    }
    return 0;
}
