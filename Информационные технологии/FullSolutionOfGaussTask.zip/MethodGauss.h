#include "Matrix.h"
Matrix GaussMethod(Matrix *);